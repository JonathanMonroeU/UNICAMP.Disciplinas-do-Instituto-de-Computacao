#include "api_car.h"

// Implemente aqui a lógica de controle do carro, utilizando as funções da api
void user_code(void) {
}
